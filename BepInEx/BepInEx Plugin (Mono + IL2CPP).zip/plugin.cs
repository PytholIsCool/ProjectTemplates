﻿using BepInEx;

[BepInPlugin("com.yourname.pluginid", "My Plugin", "1.0.0")]
public class $safeprojectname$ : BaseUnityPlugin {
    private void Awake() {
        Logger.LogInfo("Plugin loaded!");
    }
}
