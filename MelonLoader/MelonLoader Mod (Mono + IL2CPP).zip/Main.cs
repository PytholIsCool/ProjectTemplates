﻿using MelonLoader;

namespace MelonLoaderTemplateNamespace {
    public class $safeprojectname$ : MelonMod {
        public override void OnInitializeMelon() {
            LoggerInstance.Msg("Hello World!");
        }
    }
}