#include "NativeXInternal/NativeXMod.h"
#include <iostream>

// Prevent intellisense from showing false editor errors regarding seemingly incomplete functions
#ifdef __INTELLISENSE__
#else

NativeInit() {
    std::cout << "Mod initialized\n";
}

NativeUpdate() {
    std::cout << "Update tick\n";
}

NativeShutdown() {
    std::cout << "Goodbye\n";
}

#endif