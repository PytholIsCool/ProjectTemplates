#ifndef NATIVEXMOD_H
#define NATIVEXMOD_H

namespace NativeXMod {
    inline void (*initFunc)() = nullptr;
    inline void (*updateFunc)() = nullptr;
    inline void (*shutdownFunc)() = nullptr;
}

// Doing it like this works and honestly, I prefer this over having to register the functions just so there's no error messages

#define NativeInit() \
    static void __mod_init(); \
    namespace { struct __InitRegistrar { __InitRegistrar() { NativeXMod::initFunc = __mod_init; } } __init_registrar; } \
    static void __mod_init()

#define NativeUpdate() \
    static void __mod_update(); \
    namespace { struct __UpdateRegistrar { __UpdateRegistrar() { NativeXMod::updateFunc = __mod_update; } } __update_registrar; } \
    static void __mod_update()

#define NativeShutdown() \
    static void __mod_shutdown(); \
    namespace { struct __ShutdownRegistrar { __ShutdownRegistrar() { NativeXMod::shutdownFunc = __mod_shutdown; } } __shutdown_registrar; } \
    static void __mod_shutdown()



#endif // !NATIVEXMOD_H
