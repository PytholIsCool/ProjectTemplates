#include "NativeXMod.h"

extern "C" __declspec(dllexport) void OnNativeInit() {
    if (NativeXMod::initFunc) NativeXMod::initFunc();
}

extern "C" __declspec(dllexport) void OnUpdate() {
    if (NativeXMod::updateFunc) NativeXMod::updateFunc();
}

extern "C" __declspec(dllexport) void OnShutdown() {
    if (NativeXMod::shutdownFunc) NativeXMod::shutdownFunc();
}